package com.codegnan.cgecom.jspwithboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JspwithbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
