package com.codegnan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HospitalManagemSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(HospitalManagemSystemApplication.class, args);
	}

}
